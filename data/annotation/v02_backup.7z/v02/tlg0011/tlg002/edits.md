# List of Edits to the treebank

On Aug 06 2019, I have uploaded a new XML version on Arethusa, with improved
tokenization (krasis of καί and the 5 complex conjunctions).

Progress:

* ~~prune useless Artificial Nodes~~

* ~~check cases of:~~
   * ~~εἴτε, which seem undivided~~
   * ~~μηδέ: conj~~
   * ~~οὐδέ: conj~~
   * ~~οὔτε: conj~~
   * ~~μήτε: conj~~

* checking doubtful construction:
    * proleptic pronouns
    * advs with ἔχειν

* checking the `UNDEFINED` relations

* ~~checking the wrong `_ExD`~~
